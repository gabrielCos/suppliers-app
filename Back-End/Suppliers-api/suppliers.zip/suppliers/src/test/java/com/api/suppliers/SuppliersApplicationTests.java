package com.api.suppliers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SuppliersApplicationTests {

	@Test
	void contextLoads() {
	}

}
